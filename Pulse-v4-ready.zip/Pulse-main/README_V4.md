# Pulse v4 – TeamOS

Pulse wurde von einem reinen Discord-Team-Bot zu einem verbundenen Team-Management-System erweitert.

## Enthalten

- Pulse Inbox mit Benachrichtigungen und dringenden Vorgängen
- globale Suche (`CTRL + K` oder `/search`)
- Aufgaben-/Kanban-System mit Zuständigkeit, Priorität und Deadline
- Ticket 2.0 im Discord inklusive Kategorien, Team-Rechten, Claim, Transkript und Bewertungen
- Ticket-Statistiken und Prioritätsverwaltung im Webpanel
- Team-Wiki
- Schulungs-/Prüfungssystem mit frei definierbaren Fragen
- Achievement-System
- Team-Statistiken und Dienstzeitübersicht
- Team-Kalender und Meeting-Historie
- zentraler System-/Health-Check
- PWA-Grundlage (Manifest + Service Worker)
- zentrale `pulse.db` für die neuen Module
- Backups enthalten jetzt auch die neuen Pulse-Daten und LOAs
- Backup-Wiederherstellung im Panel
- Discord-Login für Bewerber statt frei eingegebener Discord-ID
- granularere Rollenrechte
- LOA-Datumsformat intern vereinheitlicht (ISO `YYYY-MM-DD`)
- verbessertes Büro-Warteraum-Rechtesystem und ausgewähltes Zielbüro wird berücksichtigt
- Activity Check mit interaktivem Bestätigungsbutton und Auswertung

## Start

1. Python 3.11+ verwenden.
2. Abhängigkeiten installieren:

```bash
python -m pip install -r requirements.txt
```

3. `.env.example` nach `.env` kopieren und Werte eintragen.
4. Für das Bewerbungs-OAuth zusätzlich diese Redirect-URI in der Discord Developer App hinterlegen:

```text
https://DEINE-DOMAIN/apply/callback
```

Bei lokaler Entwicklung entsprechend:

```text
http://localhost:25095/apply/callback
```

5. Bot starten:

```bash
python main.py
```

## Wichtige Rechte des Bots

Der Bot sollte mindestens die für die vorhandenen Funktionen nötigen Rechte besitzen, insbesondere Rollen verwalten, Mitglieder verschieben, Nachrichten verwalten und Kanäle verwalten, sofern die jeweiligen Module verwendet werden.

Die Bot-Rolle muss über den Teamrollen liegen, die Pulse automatisch verwalten soll.

## Daten

Die vorhandenen JSON-/SQLite-Daten bleiben aus Kompatibilitätsgründen bestehen. Neue Pulse-v4-Funktionen verwenden zusätzlich `pulse.db`. Beim Start wird die Datenbank automatisch angelegt und mit den Standard-Achievements initialisiert.

Ein Backup aus dem Panel enthält sowohl die bisherigen Panel-Daten als auch die neuen Pulse-v4-Daten.
